#ifndef GENERIC_6DOF_SPRING2_CONSTRAINT_DEMO_H
#define GENERIC_6DOF_SPRING2_CONSTRAINT_DEMO_H

class CommonExampleInterface* Dof6Spring2CreateFunc(struct CommonExampleOptions& options);

#endif  //GENERIC_6DOF_SPRING2_CONSTRAINT_DEMO_H
