#ifndef DYNAMIC_TEXTURED_CUBE_DEMO_H
#define DYNAMIC_TEXTURED_CUBE_DEMO_H

class CommonExampleInterface* DynamicTexturedCubeDemoCreateFunc(struct CommonExampleOptions& options);

#endif  //DYNAMIC_TEXTURED_CUBE_DEMO_H
