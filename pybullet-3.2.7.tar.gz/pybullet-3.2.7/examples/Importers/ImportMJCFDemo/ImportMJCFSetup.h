#ifndef IMPORT_MJCF_SETUP_H
#define IMPORT_MJCF_SETUP_H

class CommonExampleInterface* ImportMJCFCreateFunc(struct CommonExampleOptions& options);

#endif  //IMPORT_MJCF_SETUP_H
