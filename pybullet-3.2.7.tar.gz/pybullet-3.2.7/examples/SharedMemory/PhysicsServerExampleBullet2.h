
#ifndef PHYSICS_SERVER_EXAMPLE_BULLET_2_H
#define PHYSICS_SERVER_EXAMPLE_BULLET_2_H

class CommonExampleInterface* PhysicsServerCreateFuncBullet2(struct CommonExampleOptions& options);

#endif  //PHYSICS_SERVER_EXAMPLE_BULLET_2_H
