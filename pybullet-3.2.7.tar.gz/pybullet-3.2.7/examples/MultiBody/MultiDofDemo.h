
#ifndef MULTI_DOF_DEMO_H
#define MULTI_DOF_DEMO_H

class CommonExampleInterface* MultiDofCreateFunc(struct CommonExampleOptions& options);

#endif  //MULTI_DOF_DEMO_H
