#ifndef TEST_PENDULUM_H
#define TEST_PENDULUM_H

class CommonExampleInterface* TestPendulumCreateFunc(struct CommonExampleOptions& options);

#endif  //TEST_PENDULUM_H
